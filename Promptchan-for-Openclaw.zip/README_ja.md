# PromptChan AI 画像ジェネレータ�?
> 🎨 複数のアートスタイル、ポーズ、フィルターをサポートする高度な AI 画像生成プラットフォーム

**無料トライアル：** 新規ユーザーは簡単なタスクを完了する�?**100 無料 Gems** を獲得できます！

[English](README.md) | [中文](README_zh.md)

## 📋 目次

- [クイックスタート](#-クイックスタート)
- [登録�?API キー](#-登録�?api-キー)
- [使い方](#-使い�?
- [利用可能なスタイル](#-利用可能なスタイ�?
- [利用可能なポーズ](#-利用可能なポーズ)
- [利用可能なフィルター](#-利用可能なフィルター)
- [料金](#-料金)
- [使用例](#-使用�?
- [トラブルシューティング](#-トラブルシューティン�?
- [API リファレンス](#-api-リファレンス)

---

## 🚀 クイックスタート

### 前提条件

```bash
pip install requests
```

### 基本的な使い�?
画像を生成：

```bash
python scripts/promptchan_generate.py \
  --prompt "cute girl, school uniform, city at night, long hair" \
  --api-key "your-api-key-here" \
  --output images/output.png
```

### 残量 Gems を確�?
```bash
python scripts/promptchan_status.py --api-key "your-api-key-here"
```

---

## 📝 登録�?API キー

### 1️⃣ アカウント作�?
**重要�?* 以下の専用登録リンクを使用すると、無料スター�?Gems がもらえます�?
👉 **登録�?* https://promptchan.com/register

### 2️⃣ API キーの生�?
1. ログインして設定へ：**https://promptchan.com/settings**
2. **API Key** セクションにスクロー�?3. **"Generate"** をクリックしてキーを作成
4. API キーをコピーして保存�? 回のみ表示！�?
### 3️⃣ Gems のチャー�?
- API �?**Gems** を通貨として使�?- **1 Gem = 1 画像**
- **新規ユーザー：簡単なタスクを完了する�?100 無料 Gems�?*
- チャージ：https://promptchan.com/pricing

---

## 💻 使い�?
### コマンドライン引�?
#### 必須引数
| 引数 | 説明 |
|------|------|
| `--prompt`, `-p` | 生成したい画像を説明するプロンプ�?|
| `--api-key` | あなたの PromptChan API キー |

#### オプション引�?
**スタイル設定�?*
| 引数 | デフォル�?| 説明 |
|------|--------|------|
| `--style`, `-s` | Cinematic | アートスタイル（[スタイル一覧](#-利用可能なスタイ�? を参照） |
| `--poses` | Default | キャラクターポーズ（[ポーズ一覧](#-利用可能なポーズ) を参照） |
| `--filter`, `-f` | Default | フィルター効果（[フィルター一覧](#-利用可能なフィルター) を参照） |

**品質設定�?*
| 引数 | デフォル�?| 説明 |
|------|--------|------|
| `--quality`, `-q` | Ultra | 品質レベル（Ultra/Extreme/Max�?|
| `--detail` | 0 | 詳細レベル（-2 から 2�?|
| `--creativity`, `-c` | 50 | 創造性レベル�?0/50/70�?|

**その他：**
| 引数 | デフォル�?| 説明 |
|------|--------|------|
| `--image_size` | 512x768 | 画像サイズ（512x512/512x768/768x512�?|
| `--seed` | -1 | ランダムシード�?1 でランダム） |
| `--negative-prompt`, `-n` | - | ネガティブプロンプト |
| `--restore_faces` | false | 顔修復（+1 Gem、写実的スタイルのみ�?|
| `--output`, `-o` | 自動 | 出力ファイルパス |

### 完全な例

```bash
python scripts/promptchan_generate.py \
  --prompt "beautiful girl, long hair, sunset, detailed eyes, masterpiece" \
  --negative-prompt "ugly, deformed, noisy, blurry" \
  --style "Anime" \
  --poses "Default" \
  --filter "Cinematic" \
  --detail 1 \
  --creativity 50 \
  --quality "Ultra" \
  --image_size "512x768" \
  --seed 12345 \
  --api-key "your-api-key-here" \
  --output images/anime-girl.png
```

---

## 🎨 利用可能なスタイ�?
| スタイル | 説明 |
|------|------|
| Cinematic | 映画的レンダリン�?|
| Anime | 日本アニメスタイ�?|
| Hyperreal | 写真級写�?|
| Hyperanime | 強化アニ�?|
| K-Pop | 韓国ポップスタイ�?|
| Fur | ファリーアー�?|
| Furtoon | ファリーカートゥーン |
| Render XL+ | 強化 3D レンダ�?|
| Illustration XL+ | 強化イラスト |
| Anime XL | 大型アニメモデル |
| Anime XL+ | 強化大型アニ�?|
| Hardcore XL | インテンススタイ�?|
| Cinematic XL | 大型映画モデ�?|
| Photo XL+ | 強化フォトスタイ�?|
| Hyperreal XL+ | 強化超写�?|

**すべてのスタイルを一覧表示：**
```bash
python scripts/promptchan_styles.py --type styles
```

---

## 🧍 利用可能なポーズ

100 種類以上のポーズオプション、様々なシーンや構図に対応：

**一般的なポーズ�?*
- Default - 標準立ちポー�?- Kneeling - 膝立ちポーズ
- Sitting - 座位ポー�?- Standing - 立ちポー�?- Lying Down - 横たわるポー�?- Cuddling - 抱擁ポー�?- Smiling - 笑顔
- Looking Up - 見上げる
- From Behind - 背面ビュ�?- Close-up - クローズアッ�?
**高度なポーズ（Pro 機能）：**
- 様々な親密なポーズ
- ダイナミックアクションポー�?- 複数キャラクターのインタラクショ�?
> 📌 **注意�?* 合計 116 種類以上のポーズが利用可能。完全なリストは [SKILL.md](SKILL.md) を参照。一部のポーズは Pro サブスクリプションが必要です�?
---

## 🌈 利用可能なフィルター

| フィルタ�?| 説明 |
|--------|------|
| Default | フィルターな�?|
| Cyberpunk | ネオンフューチャリスティック |
| VHS | レトロビデオテー�?|
| Manga | コミックブックスタイ�?|
| Flash | カメラフラッシュ |
| Analog | フィルムカメラ風 |
| Professional | スタジオ品質 |
| Cinematic | 映画グレード |
| Studio | プロフェッショナル照�?|
| Polaroid | インスタントフォ�?|
| Vintage | レトロエイジ |

**すべてのフィルターを一覧表示：**
```bash
python scripts/promptchan_styles.py --type filters
```

---

## 💰 料金

| 項目 | コス�?|
|------|------|
| 基本生成 | 1 Gem/画像 |
| Extreme 品質 | +1 Gem |
| Max 品質 | +2 Gem |
| 顔修�?| +1 Gem（写実的スタイルのみ�?|
| ピーク時 | +0.25 Gem（適用される場合あり�?|

**注意�?* 1 Gem = 1 画像

---

## 📋 使用�?
### 1. アニメスタイルの女の�?
```bash
python scripts/promptchan_generate.py \
  --prompt "cute anime girl, long pink hair, school uniform, cherry blossoms" \
  --style "Anime XL+" \
  --poses "Smiling" \
  --filter "Manga" \
  --creativity 50 \
  --quality "Ultra" \
  --api-key "your-api-key" \
  --output images/anime-girl.png
```

### 2. 写実的ポートレー�?
```bash
python scripts/promptchan_generate.py \
  --prompt "beautiful korean woman, long black hair, elegant dress, studio lighting" \
  --style "Hyperreal XL+" \
  --poses "Sitting" \
  --filter "Professional" \
  --detail 1 \
  --restore_faces \
  --api-key "your-api-key" \
  --output images/portrait.png
```

### 3. サイバーパンクスタイ�?
```bash
python scripts/promptchan_generate.py \
  --prompt "cyberpunk girl, neon lights, futuristic city, night" \
  --style "Cinematic XL" \
  --filter "Cyberpunk" \
  --creativity 70 \
  --api-key "your-api-key" \
  --output images/cyberpunk.png
```

### 4. バッチ生�?
```bash
for seed in 1 2 3 4 5; do
  python scripts/promptchan_generate.py \
    --prompt "beautiful girl, sunset" \
    --style "Anime" \
    --seed $seed \
    --api-key "your-api-key" \
    --output images/batch_$seed.png
done
```

---

## 🔧 トラブルシューティン�?
### エラー：無効�?API キー
- API キーが正しくコピーされているか確�?- 余分なスペースがないか確�?- 設定�?API キーを再生成

### エラー：Gems 不足
- https://promptchan.com/pricing でチャー�?- 無料スタート Gems を請求済みか確認

### エラー：リクエストタイムアウ�?- ピーク時は遅延が発生する可能�?- ネットワーク接続を確�?- 後で再試�?
### 品質が低�?- `--detail` パラメータを増やす（1 また�?2�?- `--quality "Extreme"` また�?`"Max"` を使�?- プロンプトを改善して詳細を追�?
---

## 📚 スクリプ�?
| スクリプ�?| 説明 |
|--------|-------------|
| `promptchan_generate.py` | 画像生成 |
| `promptchan_status.py` | 残高とステータスを確�?|
| `promptchan_styles.py` | 利用可能なスタイ�?ポー�?フィルターを一覧表�?|

---

## ⚠️ 重要なお知ら�?
1. **API キーのセキュリテ�?*：API キーは非公開にし、バージョン管理にコミットしないでくださ�?2. **コンテンツガイドライ�?*：違法なコンテンツを生成しないでください（アカウント停止のリスク�?3. **コスト管�?*：生成前に十分な Gems があることを確認
4. **ピーク時**：追加料金が発生する可能性があります�?.25 Gem/画像�?5. **顔修�?*：写実的スタイルでのみ使用、アニメスタイルでは不要

---

## 🔗 リン�?
- **登録**：https://promptchan.com/m/YCYAZJj7uKQcbpP1wMcFuzA5zIY2/3hov
- **公式ドキュメント**：https://promptchan.com/docs
- **API 設定**：https://promptchan.com/settings
- **料金**：https://promptchan.com/pricing
- **作成**：https://promptchan.com/create

---

## 📄 ライセン�?
MIT License

---

## 🤝 貢献

貢献を歓迎します！PR を送信する前に、貢献ガイドラインをお読みください�?
---

## 📞 サポート

- **Discord**：[サーバーに参加](https://discord.gg/promptchan)
- **メー�?*：support@promptchan.com
- **_issues**：[GitHub Issues](https://github.com/promptchan/api/issues)

---

## 🤖 OpenClaw での使用方法

このスキルは OpenClaw に統合して、シームレス�?AI 画像生成を実現できます�?
### 方法 1：自然言語プロンプト

チャットで生成したい画像を説明するだけです：

`
画像を生成：かわいいアニメの女の子、ピンクの長い髪、制服、桜
`

`
サイバーパンクスタイルの画像を作成：ネオンライト、未来都市、夜�?`

### 方法 2：openclaw.json で設�?
openclaw.json にスキル設定を追加：

`json
{
  "skills": {
    "promptchan-for-openclaw": {
      "enabled": true,
      "apiKey": "your-api-key-here",
      "defaultStyle": "Anime",
      "defaultQuality": "Ultra"
    }
  }
}
`

短いコマンドを使用：

`
/pc アニメの女の子を生成、ピンクの髪、笑�?`

`
/promptchan サイバーパンクスタイル、ネオンライト、未来都�?`

### 方法 3：sessions_spawn を使�?
プログラムからスキルを呼び出し：

`python
from openclaw import sessions_spawn

sessions_spawn(
    task="PromptChan API で画像を生成：かわいいアニメの女の子、制服、桜",
    runtime="subagent",
    mode="run"
)
`

### 方法 4：OpenClaw ツールとして設定

openclaw.json �?tools セクションに追加�?
`json
{
  "tools": {
    "promptchan": {
      "type": "script",
      "path": "skills/promptchan-for-openclaw/scripts/promptchan_generate.py",
      "description": "PromptChan AI で画像を生成",
      "parameters": {
        "prompt": {"type": "string", "required": true},
        "style": {"type": "string", "default": "Anime"},
        "quality": {"type": "string", "default": "Ultra"}
      }
    }
  }
}
`

チャットで使用：

`
promptchan ツールを使用して生成：かわいい女の子、制服、都市の夜景
`

### プロンプト作成のヒン�?
**良いプロンプト：**
- 具体的に：かわいいアニメの女の子、ピンクの長い髪、青い目、制服、桜、笑�?- 品質用語を含む：傑作、最高品質、詳細な目�?k
- 照明と雰囲気：夕日、映画的照明、ムーディーな雰囲気

**避けるべきこと：**
- 曖昧すぎる：女の�?- 矛盾：昼と夜の混�?- 複雑すぎる：1 つのプロンプトに要素が多すぎ�?
### OpenClaw ワークフローの例

1. ユーザー：ピンクの髪のアニメの女の子を生成、制服を着てい�?2. OpenClaw �?promptchan_generate.py スクリプトを呼び出し
3. スクリプトが PromptChan API にリクエストを送信
4. API が生成された画像を返�?5. OpenClaw がユーザーに画像を表�?
詳細については、[OpenClaw ドキュメント](https://docs.openclaw.ai) を参照してください�?